#ifndef i2c_h
#define i2c_h
#include <Arduino.h>
#include <Wire.h>

class i2c
{
  private:
    int _device;                           	// I2C device address
  
  public:
		i2c(uint8_t device);
    void setDeviceAddress(uint8_t device);      // set the set the I2C device address
    uint8_t read(int location);    							// read one byte from the I2C device at the specified address
	  void seqRead(int location, uint8_t destination[], int startByte, int endByte);
		void seqWrite(int location, uint8_t source[], int startByte, int endByte);		
    void write(int location, uint8_t value);  	// write value to the I2C device at the specified address
};

#endif
