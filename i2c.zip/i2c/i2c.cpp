#include <Wire.h>
#include <i2c.h>

// Constructors
i2c::i2c(uint8_t device){
  _device = device;                     // set the I2C device address
  Wire.begin();                         // start wire()
}

void i2c::setDeviceAddress(uint8_t device){	// allow change of I2C device address
  _device = device;                     // set the device address
}

uint8_t i2c::read(int location){
// return one byte of data from location the of _device
  Wire.beginTransmission(_device);
  Wire.write(location);                 // Select memory location
  Wire.endTransmission();               // end of transmission
  Wire.requestFrom(_device, 1);         // request 1 byte of data
  while(Wire.available()<1);            // wait for data from the device
  return lowByte(Wire.read());          // return the data
}

void i2c::seqRead(int location, uint8_t destination[], int startByte, int endByte){
// reaad multiple bytes of data from location the of _device placing them in 
// startbyte through endByte of the destination array.
  Wire.beginTransmission(_device);
  Wire.write(location);                   // Select first register to write
  Wire.endTransmission();                 // end of transmission
  Wire.requestFrom(_device, (endByte-startByte)+1);
  while(Wire.available()<endByte-startByte);
  for(int i = startByte; i <= endByte; i++){
    destination[i] = Wire.read();
  }
}

void i2c::seqWrite(int location, uint8_t source[], int startByte, int endByte){
// write the multiple bytes found from startByte to endByte in source[] to 
// _device starting at location
  Wire.beginTransmission(_device);
  Wire.write(location);                   // Select first register to write
  for(int i = startByte; i <= endByte; i++){
    Wire.write(source[i]);
  }
  Wire.endTransmission();                 // end of transmission
 }

 void i2c::write (int location, uint8_t value){
// write one byte of data at location of _device
  Wire.beginTransmission(_device);
  Wire.write(location);            			// Select memory location
  Wire.write(value);                		// write the data
  Wire.endTransmission();               // end of transmission
}
