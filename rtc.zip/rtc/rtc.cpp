#include <rtc.h>

// Constructors
	rtc::rtc(){}
	
void rtc::clkHalt(){
// halt the DS1307 clock - setTime() to restart the clock, time of stop is preserved
  uint8_t reg0 = I2C.read(0x00);
  reg0 = reg0 | 0x80;                   // set bit 7
  I2C.write(0x00, reg0);                // send it back to the DS1307
}

uint8_t rtc::daysInMonth (uint8_t mon, uint8_t year){
	// return the number of days in the month/year specified (valid 2001 - 2099)
	int days;
	if(bitRead(0x15AA,mon)) days = 31;
		else {
			if (mon == 2){
				days = 29;
				if (year%4) days = 28;
			} else days = 30;
		}
	return days;
}

void rtc::getTime(){
// get BCD date/time from the DS1307 - only bytes 0-6 are needed as 7 is SQW control
		I2C.setDeviceAddress(RTC_addr);
    for (int i=0; i <= 6; i++){         // mask out unused bits
    RTCbcd[i] = I2C.read(i) & RTCmask[i];
  }
// Compute the decimal date/time
  for (int i=0; i <= 6; i++){
    RTCdec[i] = RTCbcd[i] & 0x0F;
    RTCdec[i] = RTCdec[i] + (RTCbcd[i] >> 4) * 10;
  }
  if (clock12){                       // check for 12hr clock format
    if (RTCdec[2] > 11) {
      RTCdec[2] = RTCdec[2] - 12;
      am = false;
    } else {
      am = true;
    }
  }
}

void rtc::getTimeStr(){                  
// get time from DS1307 and convert time_BCD to date and time strings
  getTime();                                        // get updated date/time from DS1307
  timeStr[0] = RTCdec[2]/10 + 0x30;                 // format the hour from decimal values as it
  timeStr[1] = RTCdec[2]%10 + 0x30;                 // has been adjusted to 12 or 24 hr format
  if (clock12){
    timeStr[10] = 'M';
    if (am) {
      timeStr[9] = 'A';
    } else {
      timeStr[9] = 'P';
    } 
  } else {
    timeStr[9] = 'h';
    timeStr[10] = 'r';
  }
  timeStr[3] = (RTCbcd[1] >> 4) + 0x30;             // minutes: shift is faster than multiplication
  timeStr[4] = (RTCbcd[1] & 0x0F) + 0x30;
  timeStr[6] = (RTCbcd[0] >> 4) + 0x30;             // seconds
  timeStr[7] = (RTCbcd[0] & 0x0F) + 0x30;
  dateStr[2] = (RTCbcd[6] >> 4) + 0x30;             // year: last two digits only
  dateStr[3] = (RTCbcd[6] & 0x0F) + 0x30;
  dateStr[5] = (RTCbcd[5] >> 4) + 0x30;             // month
  dateStr[6] = (RTCbcd[5] & 0x0F) + 0x30;
  dateStr[8] = (RTCbcd[4] >> 4) + 0x30;             // day
  dateStr[9] = (RTCbcd[4] & 0x0F) + 0x30;
	if (noSeconds) {																	// eliminate the seconds
		for(uint8_t i=5; i<= 8; i++){
			timeStr[i] = timeStr[i+3];
		}
		timeStr[8] = ' ';
	}
	else {
		timeStr[5] = ':';																// restore constants for seconds
		timeStr[8] = ' ';																//   just in case a sketch uses both
	}
}

void rtc::setSQW(uint8_t control){
// sets the DS1307 control register (addr = 0x07)
	I2C.setDeviceAddress(RTC_addr);
  I2C.write(0x07, control);
}

void rtc::setTime(){
// converts decimal date / time to BCD, and writes it to the DS1307
	I2C.setDeviceAddress(RTC_addr);
  RTCdec[3] = RTCdec[4] + 13 * (RTCdec[5] + 1) / 5; // compute day of week for safety
  RTCdec[3] = RTCdec[3] + RTCdec[6] + RTCdec[6]/4;  // Sun = 1, Sat = 7
  RTCdec[3] = (RTCdec[3] - 29)%7 + 1;
  if(clock12){
    if(!am){
      RTCdec[2] = RTCdec[2] + 12;   								// adjust for 12 hr clock
    }
  }
  for (int i=0; i <= 6; i++){
    RTCbcd[i] = ((RTCdec[i] / 10) << 4) + RTCdec[i]%10;   // do the conversion
  }
  I2C.seqWrite(0, RTCbcd, 0, 6);                    // write data to the DS1307
}
