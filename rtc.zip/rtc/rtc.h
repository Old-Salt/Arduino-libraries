#ifndef rtc_h
#define rtc_h
#include <Arduino.h>
#include <i2c.h>

class rtc
{
  private:
  uint8_t RTCbcd[7];                    // BCD data to / from DS1307 - always in 24 hr format
  uint8_t RTCmask[7] = {0x7F, 0x7F, 0x3F, 0x07, 0x3F, 0x1F, 0xFF};  // masks to exclude unused bits

  public:
  const int RTC_addr = 0x68;            // DS1307 I2C address
  uint8_t RTCdec[7];                    // decimal date / time data - 12 or 24 hr format depends on clock12
  char dateStr[12] = {'2','0','y','y','/','m','m','/','d','d','\0'};
  char timeStr[13] = {'0','0',':','0','0',':','0','0',' ','h','r','\0'};
  bool clock12 = false;                 // high for 12hr clock / low for 24 hr clock
	bool noSeconds = false;								// eliminate seconds from timeStr
  bool am = true;  
	i2c I2C = i2c(RTC_addr);

	rtc();
  void clkHalt();												// halt the DS1307 clock
  uint8_t daysInMonth (uint8_t mon, uint8_t year);  // get days in month (valid 2001 - 2099)
	void getTime();												// get BCD date/time from the DS1307 - convert to decimal
	void getTimeStr();                 		// convert time_BCD to date and time strings
	void setSQW(uint8_t control);					// sets the DS1307 control register (addr = 0x07)
	void setTime();												// converts decimal date / time to BCD, and writes it to the DS1307
};

#endif
